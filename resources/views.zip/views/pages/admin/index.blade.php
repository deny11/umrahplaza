@extends('layout.general')
@section('title', 'Admin')
@section('content')

    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2>Dashboard Admin</h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">

                <div class="bs-example" data-example-id="simple-jumbotron">
                    <div class="jumbotron">
                        <img width="100%" src="{{URL::to('pev.png')}}">
                        <h1>Semangat!</h1>
                        <p>Uangnya proyekannya buat beli bedak sama lipstick aku ya..</p>
                    </div>
                </div>

            </div>
        </div>
    </div>
@stop
@section('custom_foot')
    <script type="text/javascript">
    </script>
@stop