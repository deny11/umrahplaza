<script src="{{URL::to('assets/js/bootstrap.min.js')}}"></script>

<!-- bootstrap progress js -->
<script src="{{URL::to('assets/js/progressbar/bootstrap-progressbar.min.js')}}"></script>
<!-- icheck -->
<script src="{{URL::to('assets/js/icheck/icheck.min.js')}}"></script>

<script src="{{URL::to('assets/js/custom.js')}}"></script>
<!-- form wizard -->
<script type="text/javascript" src="{{URL::to('assets/js/wizard/jquery.smartWizard.js')}}"></script>
<!-- pace -->
<script src="{{URL::to('assets/js/pace/pace.min.js')}}"></script>

<!-- Datatables-->
<script src="{{URL::to('assets/js/datatables/jquery.dataTables.min.js')}}"></script>
<script src="{{URL::to('assets/js/datatables/dataTables.bootstrap.js')}}"></script>
<script src="{{URL::to('assets/js/datatables/dataTables.buttons.min.js')}}"></script>
<script src="{{URL::to('assets/js/datatables/buttons.bootstrap.min.js')}}"></script>
<script src="{{URL::to('assets/js/datatables/jszip.min.js')}}"></script>
<script src="{{URL::to('assets/js/datatables/pdfmake.min.js')}}"></script>
<script src="{{URL::to('assets/js/datatables/vfs_fonts.js')}}"></script>
<script src="{{URL::to('assets/js/datatables/buttons.html5.min.js')}}"></script>
<script src="{{URL::to('assets/js/datatables/buttons.print.min.js')}}"></script>
<script src="{{URL::to('assets/js/datatables/dataTables.fixedHeader.min.js')}}"></script>
<script src="{{URL::to('assets/js/datatables/dataTables.keyTable.min.js')}}"></script>
<script src="{{URL::to('assets/js/datatables/dataTables.responsive.min.js')}}"></script>
<script src="{{URL::to('assets/js/datatables/responsive.bootstrap.min.js')}}"></script>
<script src="{{URL::to('assets/js/datatables/dataTables.scroller.min.js')}}"></script>

<!-- select2 -->
<script src="{{URL::to('assets/js/select/select2.full.js')}}"></script>

<!-- daterangepicker -->
<script type="text/javascript" src="{{URL::to('assets/js/moment/moment.min.js')}}"></script>
<script type="text/javascript" src="{{URL::to('assets/js/datepicker/daterangepicker.js')}}"></script>